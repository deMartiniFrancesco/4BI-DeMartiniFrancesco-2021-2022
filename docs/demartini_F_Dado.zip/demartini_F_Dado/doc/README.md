# Program name: Dado.java

---

## Consegna

Definire la classe Dado. Un dado � caratterizzato dal numero di facce (minimo 6) e dal fatto che sia truccato o non truccato. 
Si implementi il metodo lancia(), che restituisce: un numero casuale se il dado non � truccato, il numero 3 se il dado � truccato.
Realizzare
- UML della classe
- classe Dado
- classe UsaDado (che genera oggetti di classe Dado e li lancia, stampando il risultato dei lanci)



